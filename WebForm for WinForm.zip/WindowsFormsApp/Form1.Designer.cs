﻿namespace WindowsFormsApp
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.菜单aToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单bToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单CToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.关闭ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.菜单aToolStripMenuItem,
            this.菜单bToolStripMenuItem,
            this.菜单CToolStripMenuItem,
            this.关闭ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(315, 25);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 菜单aToolStripMenuItem
            // 
            this.菜单aToolStripMenuItem.Name = "菜单aToolStripMenuItem";
            this.菜单aToolStripMenuItem.Size = new System.Drawing.Size(51, 21);
            this.菜单aToolStripMenuItem.Text = "菜单a";
            // 
            // 菜单bToolStripMenuItem
            // 
            this.菜单bToolStripMenuItem.Name = "菜单bToolStripMenuItem";
            this.菜单bToolStripMenuItem.Size = new System.Drawing.Size(52, 21);
            this.菜单bToolStripMenuItem.Text = "菜单b";
            // 
            // 菜单CToolStripMenuItem
            // 
            this.菜单CToolStripMenuItem.Name = "菜单CToolStripMenuItem";
            this.菜单CToolStripMenuItem.Size = new System.Drawing.Size(52, 21);
            this.菜单CToolStripMenuItem.Text = "菜单C";
            // 
            // 关闭ToolStripMenuItem
            // 
            this.关闭ToolStripMenuItem.Name = "关闭ToolStripMenuItem";
            this.关闭ToolStripMenuItem.Size = new System.Drawing.Size(48, 21);
            this.关闭ToolStripMenuItem.Text = " 关闭";
            this.关闭ToolStripMenuItem.Click += new System.EventHandler(this.关闭ToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(315, 246);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 菜单aToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 菜单bToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 菜单CToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 关闭ToolStripMenuItem;


    }
}

